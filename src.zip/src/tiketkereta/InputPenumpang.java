package tiketkereta;
import java.util.Scanner;

class InputPenumpang {
    protected Scanner input = new Scanner(System.in);
    }

