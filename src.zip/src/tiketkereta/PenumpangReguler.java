package tiketkereta;
class PenumpangReguler extends Penumpang {
    public PenumpangReguler(String nama, String noTiket) {
        super(nama, noTiket);
    }
    
    @Override
    public double hitungHargaTiket() {
       return 80000;
    }
}