package tiketkereta;


abstract class Penumpang {
    protected String nama;
    protected String noTiket;
    
    
    public Penumpang(String nama, String noTiket) {
        this.nama = nama;
        this.noTiket = noTiket;
    }

    public abstract double hitungHargaTiket();

    public void tampilkanData() {
        System.out.println("Nama        \t: " + nama);
        System.out.println("No Tiket    \t: " + noTiket);
        System.out.println("Harga Tiket \t: Rp. " + hitungHargaTiket());
        System.out.println("Jenis       \t: Reguler");
    }
    
    public void tampilkanData(String jenis) {
        System.out.println("Nama        \t: " + nama);
        System.out.println("No Tiket    \t: " + noTiket);
        System.out.println("Harga Tiket \t: Rp. " + hitungHargaTiket());
        System.out.println("Jenis       \t: " + jenis);
    }
}


